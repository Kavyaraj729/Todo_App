import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import sequelize, { initDb } from "./config/db.js";
import userRouter from "./routes/userRoute.js";
import taskRouter from "./routes/taskRoute.js";
import forgotPasswordRouter from "./routes/forgotPassword.js";

// app config
dotenv.config();
const app = express();
const port = process.env.PORT || 8001;

// middlewares
app.use(express.json());
app.use(cors());

// db config & table sync
(async () => {
    try {
        await initDb();
        await sequelize.authenticate();
        console.log("MySQL DB Connected");
        await sequelize.sync();
        console.log("Database synchronized");
    } catch (err) {
        console.error("Database connection error:", err.message);
    }
})();

// api endpoints
app.use("/api/user", userRouter);
app.use("/api/task", taskRouter);
app.use("/api/forgotPassword", forgotPasswordRouter);

// listen
app.listen(port, () => console.log(`Listening on localhost:${port}`));