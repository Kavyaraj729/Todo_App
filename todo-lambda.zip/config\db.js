import { Sequelize } from "sequelize";
import mysql from "mysql2/promise";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, "../../.env") });

const host = process.env.MYSQL_HOST || "localhost";
const port = process.env.MYSQL_PORT ? parseInt(process.env.MYSQL_PORT) : 3306;
const user = process.env.MYSQL_USER || "root";
const password = process.env.MYSQL_PASSWORD !== undefined ? process.env.MYSQL_PASSWORD : "";
const database = process.env.MYSQL_DB || "todo_db";

export const initDb = async () => {
  if (!process.env.MYSQL_URI) {
    try {
      const connection = await mysql.createConnection({ host, port, user, password });
      await connection.query(`CREATE DATABASE IF NOT EXISTS \`${database}\`;`);
      await connection.end();
    } catch (err) {
      // Notice for pre-creation error (e.g. wrong password or connection issue)
    }
  }
};

const sequelize = process.env.MYSQL_URI
  ? new Sequelize(process.env.MYSQL_URI, { dialect: "mysql", logging: false })
  : new Sequelize(database, user, password, {
      host,
      port,
      dialect: "mysql",
      logging: false,
    });

export default sequelize;
